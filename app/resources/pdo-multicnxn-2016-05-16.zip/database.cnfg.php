<?php
$pg_db_type = "mysql";
$pg_db_server = "127.0.0.1";
$pg_db_user = "root";
$pg_db_pass = "";
$pg_db_db = "test";
$pg_db_port   = "3306";
?>