﻿<?php
echo '<pre>
For advance examples please check pdo_database.class_manual.php file.

In this file your learn to use transactions and secure querys for avoid sql injections.</pre>';
?>